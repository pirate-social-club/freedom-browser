#ifndef HSK_SECP256K1_H
#define HSK_SECP256K1_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>

/* These rules specify the order of arguments in API calls:
 *
 * 1. Context pointers go first, followed by output arguments, combined
 *    output/input arguments, and finally input-only arguments.
 * 2. Array lengths always immediately the follow the argument whose length
 *    they describe, even if this violates rule 1.
 * 3. Within the OUT/OUTIN/IN groups, pointers to data that is typically generated
 *    later go first. This means: signatures, public nonces, private nonces,
 *    messages, public keys, secret keys, tweaks.
 * 4. Arguments that are not data pointers go last, from more complex to less
 *    complex: function pointers, algorithm names, messages, void pointers,
 *    counts, flags, booleans.
 * 5. Opaque data pointers follow the function pointer they are to be passed to.
 */

/** Opaque data structure that holds context information (precomputed tables etc.).
 *
 *  The purpose of context structures is to cache large precomputed data tables
 *  that are expensive to construct, and also to maintain the randomization data
 *  for blinding.
 *
 *  Do not create a new context object for each operation, as construction is
 *  far slower than all other API calls (~100 times slower than an ECDSA
 *  verification).
 *
 *  A constructed context can safely be used from multiple threads
 *  simultaneously, but API call that take a non-const pointer to a context
 *  need exclusive access to it. In particular this is the case for
 *  hsk_secp256k1_context_destroy and hsk_secp256k1_context_randomize.
 *
 *  Regarding randomization, either do it once at creation time (in which case
 *  you do not need any locking for the other calls), or use a read-write lock.
 */
typedef struct hsk_secp256k1_context_struct hsk_secp256k1_context;

/** Opaque data structure that holds rewriteable "scratch space"
 *
 *  The purpose of this structure is to replace dynamic memory allocations,
 *  because we target architectures where this may not be available. It is
 *  essentially a resizable (within specified parameters) block of bytes,
 *  which is initially created either by memory allocation or TODO as a pointer
 *  into some fixed rewritable space.
 *
 *  Unlike the context object, this cannot safely be shared between threads
 *  without additional synchronization logic.
 */
typedef struct hsk_secp256k1_scratch_space_struct hsk_secp256k1_scratch_space;

/** Opaque data structure that holds a parsed and valid public key.
 *
 *  The exact representation of data inside is implementation defined and not
 *  guaranteed to be portable between different platforms or versions. It is
 *  however guaranteed to be 64 bytes in size, and can be safely copied/moved.
 *  If you need to convert to a format suitable for storage, transmission, or
 *  comparison, use hsk_secp256k1_ec_pubkey_serialize and hsk_secp256k1_ec_pubkey_parse.
 */
typedef struct {
    unsigned char data[64];
} hsk_secp256k1_pubkey;

/** Opaque data structured that holds a parsed ECDSA signature.
 *
 *  The exact representation of data inside is implementation defined and not
 *  guaranteed to be portable between different platforms or versions. It is
 *  however guaranteed to be 64 bytes in size, and can be safely copied/moved.
 *  If you need to convert to a format suitable for storage, transmission, or
 *  comparison, use the hsk_secp256k1_ecdsa_signature_serialize_* and
 *  hsk_secp256k1_ecdsa_signature_parse_* functions.
 */
typedef struct {
    unsigned char data[64];
} hsk_secp256k1_ecdsa_signature;

/** A pointer to a function to deterministically generate a nonce.
 *
 * Returns: 1 if a nonce was successfully generated. 0 will cause signing to fail.
 * Out:     nonce32:   pointer to a 32-byte array to be filled by the function.
 * In:      msg32:     the 32-byte message hash being verified (will not be NULL)
 *          key32:     pointer to a 32-byte secret key (will not be NULL)
 *          algo16:    pointer to a 16-byte array describing the signature
 *                     algorithm (will be NULL for ECDSA for compatibility).
 *          data:      Arbitrary data pointer that is passed through.
 *          attempt:   how many iterations we have tried to find a nonce.
 *                     This will almost always be 0, but different attempt values
 *                     are required to result in a different nonce.
 *
 * Except for test cases, this function should compute some cryptographic hash of
 * the message, the algorithm, the key and the attempt.
 */
typedef int (*hsk_secp256k1_nonce_function)(
    unsigned char *nonce32,
    const unsigned char *msg32,
    const unsigned char *key32,
    const unsigned char *algo16,
    void *data,
    unsigned int attempt
);

# if !defined(HSK_SECP256K1_GNUC_PREREQ)
#  if defined(__GNUC__)&&defined(__GNUC_MINOR__)
#   define HSK_SECP256K1_GNUC_PREREQ(_maj,_min) \
 ((__GNUC__<<16)+__GNUC_MINOR__>=((_maj)<<16)+(_min))
#  else
#   define HSK_SECP256K1_GNUC_PREREQ(_maj,_min) 0
#  endif
# endif

# if (!defined(__STDC_VERSION__) || (__STDC_VERSION__ < 199901L) )
#  if HSK_SECP256K1_GNUC_PREREQ(2,7)
#   define HSK_SECP256K1_INLINE __inline__
#  elif (defined(_MSC_VER))
#   define HSK_SECP256K1_INLINE __inline
#  else
#   define HSK_SECP256K1_INLINE
#  endif
# else
#  define HSK_SECP256K1_INLINE inline
# endif

#ifndef HSK_SECP256K1_API
# if defined(_WIN32)
#  ifdef HSK_BUILD
#   define HSK_SECP256K1_API __declspec(dllexport)
#  else
#   define HSK_SECP256K1_API
#  endif
# elif defined(__GNUC__) && defined(HSK_BUILD)
#  define HSK_SECP256K1_API __attribute__ ((visibility ("default")))
# else
#  define HSK_SECP256K1_API
# endif
#endif

/**Warning attributes
  * NONNULL is not used if HSK_BUILD is set to avoid the compiler optimizing out
  * some paranoid null checks. */
# if defined(__GNUC__) && HSK_SECP256K1_GNUC_PREREQ(3, 4)
#  define HSK_SECP256K1_WARN_UNUSED_RESULT __attribute__ ((__warn_unused_result__))
# else
#  define HSK_SECP256K1_WARN_UNUSED_RESULT
# endif
# if !defined(HSK_BUILD) && defined(__GNUC__) && HSK_SECP256K1_GNUC_PREREQ(3, 4)
#  define HSK_SECP256K1_ARG_NONNULL(_x)  __attribute__ ((__nonnull__(_x)))
# else
#  define HSK_SECP256K1_ARG_NONNULL(_x)
# endif

/** All flags' lower 8 bits indicate what they're for. Do not use directly. */
#define HSK_SECP256K1_FLAGS_TYPE_MASK ((1 << 8) - 1)
#define HSK_SECP256K1_FLAGS_TYPE_CONTEXT (1 << 0)
#define HSK_SECP256K1_FLAGS_TYPE_COMPRESSION (1 << 1)
/** The higher bits contain the actual data. Do not use directly. */
#define HSK_SECP256K1_FLAGS_BIT_CONTEXT_VERIFY (1 << 8)
#define HSK_SECP256K1_FLAGS_BIT_CONTEXT_SIGN (1 << 9)
#define HSK_SECP256K1_FLAGS_BIT_COMPRESSION (1 << 8)

/** Flags to pass to hsk_secp256k1_context_create. */
#define HSK_SECP256K1_CONTEXT_VERIFY (HSK_SECP256K1_FLAGS_TYPE_CONTEXT | HSK_SECP256K1_FLAGS_BIT_CONTEXT_VERIFY)
#define HSK_SECP256K1_CONTEXT_SIGN (HSK_SECP256K1_FLAGS_TYPE_CONTEXT | HSK_SECP256K1_FLAGS_BIT_CONTEXT_SIGN)
#define HSK_SECP256K1_CONTEXT_NONE (HSK_SECP256K1_FLAGS_TYPE_CONTEXT)

/** Flag to pass to hsk_secp256k1_ec_pubkey_serialize and hsk_secp256k1_ec_privkey_export. */
#define HSK_SECP256K1_EC_COMPRESSED (HSK_SECP256K1_FLAGS_TYPE_COMPRESSION | HSK_SECP256K1_FLAGS_BIT_COMPRESSION)
#define HSK_SECP256K1_EC_UNCOMPRESSED (HSK_SECP256K1_FLAGS_TYPE_COMPRESSION)

/** Prefix byte used to tag various encoded curvepoints for specific purposes */
#define HSK_SECP256K1_TAG_PUBKEY_EVEN 0x02
#define HSK_SECP256K1_TAG_PUBKEY_ODD 0x03
#define HSK_SECP256K1_TAG_PUBKEY_UNCOMPRESSED 0x04
#define HSK_SECP256K1_TAG_PUBKEY_HYBRID_EVEN 0x06
#define HSK_SECP256K1_TAG_PUBKEY_HYBRID_ODD 0x07

/** Create a secp256k1 context object.
 *
 *  Returns: a newly created context object.
 *  In:      flags: which parts of the context to initialize.
 *
 *  See also hsk_secp256k1_context_randomize.
 */
HSK_SECP256K1_API hsk_secp256k1_context* hsk_secp256k1_context_create(
    unsigned int flags
) HSK_SECP256K1_WARN_UNUSED_RESULT;

/** Copies a secp256k1 context object.
 *
 *  Returns: a newly created context object.
 *  Args:    ctx: an existing context to copy (cannot be NULL)
 */
HSK_SECP256K1_API hsk_secp256k1_context* hsk_secp256k1_context_clone(
    const hsk_secp256k1_context* ctx
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_WARN_UNUSED_RESULT;

/** Destroy a secp256k1 context object.
 *
 *  The context pointer may not be used afterwards.
 *  Args:   ctx: an existing context to destroy (cannot be NULL)
 */
HSK_SECP256K1_API void hsk_secp256k1_context_destroy(
    hsk_secp256k1_context* ctx
);

/** Set a callback function to be called when an illegal argument is passed to
 *  an API call. It will only trigger for violations that are mentioned
 *  explicitly in the header.
 *
 *  The philosophy is that these shouldn't be dealt with through a
 *  specific return value, as calling code should not have branches to deal with
 *  the case that this code itself is broken.
 *
 *  On the other hand, during debug stage, one would want to be informed about
 *  such mistakes, and the default (crashing) may be inadvisable.
 *  When this callback is triggered, the API function called is guaranteed not
 *  to cause a crash, though its return value and output arguments are
 *  undefined.
 *
 *  Args: ctx:  an existing context object (cannot be NULL)
 *  In:   fun:  a pointer to a function to call when an illegal argument is
 *              passed to the API, taking a message and an opaque pointer
 *              (NULL restores a default handler that calls abort).
 *        data: the opaque pointer to pass to fun above.
 */
HSK_SECP256K1_API void hsk_secp256k1_context_set_illegal_callback(
    hsk_secp256k1_context* ctx,
    void (*fun)(const char* message, void* data),
    const void* data
) HSK_SECP256K1_ARG_NONNULL(1);

/** Set a callback function to be called when an internal consistency check
 *  fails. The default is crashing.
 *
 *  This can only trigger in case of a hardware failure, miscompilation,
 *  memory corruption, serious bug in the library, or other error would can
 *  otherwise result in undefined behaviour. It will not trigger due to mere
 *  incorrect usage of the API (see hsk_secp256k1_context_set_illegal_callback
 *  for that). After this callback returns, anything may happen, including
 *  crashing.
 *
 *  Args: ctx:  an existing context object (cannot be NULL)
 *  In:   fun:  a pointer to a function to call when an internal error occurs,
 *              taking a message and an opaque pointer (NULL restores a default
 *              handler that calls abort).
 *        data: the opaque pointer to pass to fun above.
 */
HSK_SECP256K1_API void hsk_secp256k1_context_set_error_callback(
    hsk_secp256k1_context* ctx,
    void (*fun)(const char* message, void* data),
    const void* data
) HSK_SECP256K1_ARG_NONNULL(1);

/** Create a secp256k1 scratch space object.
 *
 *  Returns: a newly created scratch space.
 *  Args: ctx:  an existing context object (cannot be NULL)
 *  In:  init_size: initial amount of memory to allocate
 *        max_size: maximum amount of memory to allocate
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT hsk_secp256k1_scratch_space* hsk_secp256k1_scratch_space_create(
    const hsk_secp256k1_context* ctx,
    size_t init_size,
    size_t max_size
) HSK_SECP256K1_ARG_NONNULL(1);

/** Destroy a secp256k1 scratch space.
 *
 *  The pointer may not be used afterwards.
 *  Args:   scratch: space to destroy
 */
HSK_SECP256K1_API void hsk_secp256k1_scratch_space_destroy(
    hsk_secp256k1_scratch_space* scratch
);

/** Parse a variable-length public key into the pubkey object.
 *
 *  Returns: 1 if the public key was fully valid.
 *           0 if the public key could not be parsed or is invalid.
 *  Args: ctx:      a secp256k1 context object.
 *  Out:  pubkey:   pointer to a pubkey object. If 1 is returned, it is set to a
 *                  parsed version of input. If not, its value is undefined.
 *  In:   input:    pointer to a serialized public key
 *        inputlen: length of the array pointed to by input
 *
 *  This function supports parsing compressed (33 bytes, header byte 0x02 or
 *  0x03), uncompressed (65 bytes, header byte 0x04), or hybrid (65 bytes, header
 *  byte 0x06 or 0x07) format public keys.
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_pubkey_parse(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_pubkey* pubkey,
    const unsigned char *input,
    size_t inputlen
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Serialize a pubkey object into a serialized byte sequence.
 *
 *  Returns: 1 always.
 *  Args:   ctx:        a secp256k1 context object.
 *  Out:    output:     a pointer to a 65-byte (if compressed==0) or 33-byte (if
 *                      compressed==1) byte array to place the serialized key
 *                      in.
 *  In/Out: outputlen:  a pointer to an integer which is initially set to the
 *                      size of output, and is overwritten with the written
 *                      size.
 *  In:     pubkey:     a pointer to a hsk_secp256k1_pubkey containing an
 *                      initialized public key.
 *          flags:      HSK_SECP256K1_EC_COMPRESSED if serialization should be in
 *                      compressed format, otherwise HSK_SECP256K1_EC_UNCOMPRESSED.
 */
HSK_SECP256K1_API int hsk_secp256k1_ec_pubkey_serialize(
    const hsk_secp256k1_context* ctx,
    unsigned char *output,
    size_t *outputlen,
    const hsk_secp256k1_pubkey* pubkey,
    unsigned int flags
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3) HSK_SECP256K1_ARG_NONNULL(4);

/** Parse an ECDSA signature in compact (64 bytes) format.
 *
 *  Returns: 1 when the signature could be parsed, 0 otherwise.
 *  Args: ctx:      a secp256k1 context object
 *  Out:  sig:      a pointer to a signature object
 *  In:   input64:  a pointer to the 64-byte array to parse
 *
 *  The signature must consist of a 32-byte big endian R value, followed by a
 *  32-byte big endian S value. If R or S fall outside of [0..order-1], the
 *  encoding is invalid. R and S with value 0 are allowed in the encoding.
 *
 *  After the call, sig will always be initialized. If parsing failed or R or
 *  S are zero, the resulting sig value is guaranteed to fail validation for any
 *  message and public key.
 */
HSK_SECP256K1_API int hsk_secp256k1_ecdsa_signature_parse_compact(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_ecdsa_signature* sig,
    const unsigned char *input64
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Parse a DER ECDSA signature.
 *
 *  Returns: 1 when the signature could be parsed, 0 otherwise.
 *  Args: ctx:      a secp256k1 context object
 *  Out:  sig:      a pointer to a signature object
 *  In:   input:    a pointer to the signature to be parsed
 *        inputlen: the length of the array pointed to be input
 *
 *  This function will accept any valid DER encoded signature, even if the
 *  encoded numbers are out of range.
 *
 *  After the call, sig will always be initialized. If parsing failed or the
 *  encoded numbers are out of range, signature validation with it is
 *  guaranteed to fail for every message and public key.
 */
HSK_SECP256K1_API int hsk_secp256k1_ecdsa_signature_parse_der(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_ecdsa_signature* sig,
    const unsigned char *input,
    size_t inputlen
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Serialize an ECDSA signature in DER format.
 *
 *  Returns: 1 if enough space was available to serialize, 0 otherwise
 *  Args:   ctx:       a secp256k1 context object
 *  Out:    output:    a pointer to an array to store the DER serialization
 *  In/Out: outputlen: a pointer to a length integer. Initially, this integer
 *                     should be set to the length of output. After the call
 *                     it will be set to the length of the serialization (even
 *                     if 0 was returned).
 *  In:     sig:       a pointer to an initialized signature object
 */
HSK_SECP256K1_API int hsk_secp256k1_ecdsa_signature_serialize_der(
    const hsk_secp256k1_context* ctx,
    unsigned char *output,
    size_t *outputlen,
    const hsk_secp256k1_ecdsa_signature* sig
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3) HSK_SECP256K1_ARG_NONNULL(4);

/** Serialize an ECDSA signature in compact (64 byte) format.
 *
 *  Returns: 1
 *  Args:   ctx:       a secp256k1 context object
 *  Out:    output64:  a pointer to a 64-byte array to store the compact serialization
 *  In:     sig:       a pointer to an initialized signature object
 *
 *  See hsk_secp256k1_ecdsa_signature_parse_compact for details about the encoding.
 */
HSK_SECP256K1_API int hsk_secp256k1_ecdsa_signature_serialize_compact(
    const hsk_secp256k1_context* ctx,
    unsigned char *output64,
    const hsk_secp256k1_ecdsa_signature* sig
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Verify an ECDSA signature.
 *
 *  Returns: 1: correct signature
 *           0: incorrect or unparseable signature
 *  Args:    ctx:       a secp256k1 context object, initialized for verification.
 *  In:      sig:       the signature being verified (cannot be NULL)
 *           msg32:     the 32-byte message hash being verified (cannot be NULL)
 *           pubkey:    pointer to an initialized public key to verify with (cannot be NULL)
 *
 * To avoid accepting malleable signatures, only ECDSA signatures in lower-S
 * form are accepted.
 *
 * If you need to accept ECDSA signatures from sources that do not obey this
 * rule, apply hsk_secp256k1_ecdsa_signature_normalize to the signature prior to
 * validation, but be aware that doing so results in malleable signatures.
 *
 * For details, see the comments for that function.
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ecdsa_verify(
    const hsk_secp256k1_context* ctx,
    const hsk_secp256k1_ecdsa_signature *sig,
    const unsigned char *msg32,
    const hsk_secp256k1_pubkey *pubkey
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3) HSK_SECP256K1_ARG_NONNULL(4);

/** Convert a signature to a normalized lower-S form.
 *
 *  Returns: 1 if sigin was not normalized, 0 if it already was.
 *  Args: ctx:    a secp256k1 context object
 *  Out:  sigout: a pointer to a signature to fill with the normalized form,
 *                or copy if the input was already normalized. (can be NULL if
 *                you're only interested in whether the input was already
 *                normalized).
 *  In:   sigin:  a pointer to a signature to check/normalize (cannot be NULL,
 *                can be identical to sigout)
 *
 *  With ECDSA a third-party can forge a second distinct signature of the same
 *  message, given a single initial signature, but without knowing the key. This
 *  is done by negating the S value modulo the order of the curve, 'flipping'
 *  the sign of the random point R which is not included in the signature.
 *
 *  Forgery of the same message isn't universally problematic, but in systems
 *  where message malleability or uniqueness of signatures is important this can
 *  cause issues. This forgery can be blocked by all verifiers forcing signers
 *  to use a normalized form.
 *
 *  The lower-S form reduces the size of signatures slightly on average when
 *  variable length encodings (such as DER) are used and is cheap to verify,
 *  making it a good choice. Security of always using lower-S is assured because
 *  anyone can trivially modify a signature after the fact to enforce this
 *  property anyway.
 *
 *  The lower S value is always between 0x1 and
 *  0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0,
 *  inclusive.
 *
 *  No other forms of ECDSA malleability are known and none seem likely, but
 *  there is no formal proof that ECDSA, even with this additional restriction,
 *  is free of other malleability. Commonly used serialization schemes will also
 *  accept various non-unique encodings, so care should be taken when this
 *  property is required for an application.
 *
 *  The hsk_secp256k1_ecdsa_sign function will by default create signatures in the
 *  lower-S form, and hsk_secp256k1_ecdsa_verify will not accept others. In case
 *  signatures come from a system that cannot enforce this property,
 *  hsk_secp256k1_ecdsa_signature_normalize must be called before verification.
 */
HSK_SECP256K1_API int hsk_secp256k1_ecdsa_signature_normalize(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_ecdsa_signature *sigout,
    const hsk_secp256k1_ecdsa_signature *sigin
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(3);

/** An implementation of RFC6979 (using HMAC-SHA256) as nonce generation function.
 * If a data pointer is passed, it is assumed to be a pointer to 32 bytes of
 * extra entropy.
 */
HSK_SECP256K1_API extern const hsk_secp256k1_nonce_function hsk_secp256k1_nonce_function_rfc6979;

/** A default safe nonce generation function (currently equal to hsk_secp256k1_nonce_function_rfc6979). */
HSK_SECP256K1_API extern const hsk_secp256k1_nonce_function hsk_secp256k1_nonce_function_default;

/** Create an ECDSA signature.
 *
 *  Returns: 1: signature created
 *           0: the nonce generation function failed, or the private key was invalid.
 *  Args:    ctx:    pointer to a context object, initialized for signing (cannot be NULL)
 *  Out:     sig:    pointer to an array where the signature will be placed (cannot be NULL)
 *  In:      msg32:  the 32-byte message hash being signed (cannot be NULL)
 *           seckey: pointer to a 32-byte secret key (cannot be NULL)
 *           noncefp:pointer to a nonce generation function. If NULL, hsk_secp256k1_nonce_function_default is used
 *           ndata:  pointer to arbitrary data used by the nonce generation function (can be NULL)
 *
 * The created signature is always in lower-S form. See
 * hsk_secp256k1_ecdsa_signature_normalize for more details.
 */
HSK_SECP256K1_API int hsk_secp256k1_ecdsa_sign(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_ecdsa_signature *sig,
    const unsigned char *msg32,
    const unsigned char *seckey,
    hsk_secp256k1_nonce_function noncefp,
    const void *ndata
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3) HSK_SECP256K1_ARG_NONNULL(4);

/** Verify an ECDSA secret key.
 *
 *  Returns: 1: secret key is valid
 *           0: secret key is invalid
 *  Args:    ctx: pointer to a context object (cannot be NULL)
 *  In:      seckey: pointer to a 32-byte secret key (cannot be NULL)
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_seckey_verify(
    const hsk_secp256k1_context* ctx,
    const unsigned char *seckey
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2);

/** Compute the public key for a secret key.
 *
 *  Returns: 1: secret was valid, public key stores
 *           0: secret was invalid, try again
 *  Args:   ctx:        pointer to a context object, initialized for signing (cannot be NULL)
 *  Out:    pubkey:     pointer to the created public key (cannot be NULL)
 *  In:     seckey:     pointer to a 32-byte private key (cannot be NULL)
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_pubkey_create(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_pubkey *pubkey,
    const unsigned char *seckey
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Negates a private key in place.
 *
 *  Returns: 1 always
 *  Args:   ctx:        pointer to a context object
 *  In/Out: pubkey:     pointer to the public key to be negated (cannot be NULL)
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_privkey_negate(
    const hsk_secp256k1_context* ctx,
    unsigned char *seckey
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2);

/** Negates a public key in place.
 *
 *  Returns: 1 always
 *  Args:   ctx:        pointer to a context object
 *  In/Out: pubkey:     pointer to the public key to be negated (cannot be NULL)
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_pubkey_negate(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_pubkey *pubkey
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2);

/** Tweak a private key by adding tweak to it.
 * Returns: 0 if the tweak was out of range (chance of around 1 in 2^128 for
 *          uniformly random 32-byte arrays, or if the resulting private key
 *          would be invalid (only when the tweak is the complement of the
 *          private key). 1 otherwise.
 * Args:    ctx:    pointer to a context object (cannot be NULL).
 * In/Out:  seckey: pointer to a 32-byte private key.
 * In:      tweak:  pointer to a 32-byte tweak.
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_privkey_tweak_add(
    const hsk_secp256k1_context* ctx,
    unsigned char *seckey,
    const unsigned char *tweak
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Tweak a public key by adding tweak times the generator to it.
 * Returns: 0 if the tweak was out of range (chance of around 1 in 2^128 for
 *          uniformly random 32-byte arrays, or if the resulting public key
 *          would be invalid (only when the tweak is the complement of the
 *          corresponding private key). 1 otherwise.
 * Args:    ctx:    pointer to a context object initialized for validation
 *                  (cannot be NULL).
 * In/Out:  pubkey: pointer to a public key object.
 * In:      tweak:  pointer to a 32-byte tweak.
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_pubkey_tweak_add(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_pubkey *pubkey,
    const unsigned char *tweak
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Tweak a private key by multiplying it by a tweak.
 * Returns: 0 if the tweak was out of range (chance of around 1 in 2^128 for
 *          uniformly random 32-byte arrays, or equal to zero. 1 otherwise.
 * Args:   ctx:    pointer to a context object (cannot be NULL).
 * In/Out: seckey: pointer to a 32-byte private key.
 * In:     tweak:  pointer to a 32-byte tweak.
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_privkey_tweak_mul(
    const hsk_secp256k1_context* ctx,
    unsigned char *seckey,
    const unsigned char *tweak
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Tweak a public key by multiplying it by a tweak value.
 * Returns: 0 if the tweak was out of range (chance of around 1 in 2^128 for
 *          uniformly random 32-byte arrays, or equal to zero. 1 otherwise.
 * Args:    ctx:    pointer to a context object initialized for validation
 *                 (cannot be NULL).
 * In/Out:  pubkey: pointer to a public key obkect.
 * In:      tweak:  pointer to a 32-byte tweak.
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_pubkey_tweak_mul(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_pubkey *pubkey,
    const unsigned char *tweak
) HSK_SECP256K1_ARG_NONNULL(1) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

/** Updates the context randomization to protect against side-channel leakage.
 *  Returns: 1: randomization successfully updated
 *           0: error
 *  Args:    ctx:       pointer to a context object (cannot be NULL)
 *  In:      seed32:    pointer to a 32-byte random seed (NULL resets to initial state)
 *
 * While secp256k1 code is written to be constant-time no matter what secret
 * values are, it's possible that a future compiler may output code which isn't,
 * and also that the CPU may not emit the same radio frequencies or draw the same
 * amount power for all values.
 *
 * This function provides a seed which is combined into the blinding value: that
 * blinding value is added before each multiplication (and removed afterwards) so
 * that it does not affect function results, but shields against attacks which
 * rely on any input-dependent behaviour.
 *
 * You should call this after hsk_secp256k1_context_create or
 * hsk_secp256k1_context_clone, and may call this repeatedly afterwards.
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_context_randomize(
    hsk_secp256k1_context* ctx,
    const unsigned char *seed32
) HSK_SECP256K1_ARG_NONNULL(1);

/** Add a number of public keys together.
 *  Returns: 1: the sum of the public keys is valid.
 *           0: the sum of the public keys is not valid.
 *  Args:   ctx:        pointer to a context object
 *  Out:    out:        pointer to a public key object for placing the resulting public key
 *                      (cannot be NULL)
 *  In:     ins:        pointer to array of pointers to public keys (cannot be NULL)
 *          n:          the number of public keys to add together (must be at least 1)
 */
HSK_SECP256K1_API HSK_SECP256K1_WARN_UNUSED_RESULT int hsk_secp256k1_ec_pubkey_combine(
    const hsk_secp256k1_context* ctx,
    hsk_secp256k1_pubkey *out,
    const hsk_secp256k1_pubkey * const * ins,
    size_t n
) HSK_SECP256K1_ARG_NONNULL(2) HSK_SECP256K1_ARG_NONNULL(3);

#include "ecdh.h"
#include "recovery.h"

#ifdef __cplusplus
}
#endif

#endif /* HSK_SECP256K1_H */
